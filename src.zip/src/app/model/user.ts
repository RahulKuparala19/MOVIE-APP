export class User {
    uid: number;
    uname: string;
    uemail: string;
    upassword: string;
    

  
    constructor() {
      this.uid = 0;
      this.uname = '';
      this.uemail='';
      this.upassword = '';
      
    }
  }